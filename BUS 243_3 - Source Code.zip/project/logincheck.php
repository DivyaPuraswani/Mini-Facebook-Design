<?php
session_start();
include 'conn2.php';

$EMAIL=$_POST['email'];
$PASS=$_POST['pass'];

$sql1="select * from USER_TABLE where USER_EMAIL='".$EMAIL."' and PASSWORD='".$PASS."'";
$res1=mysqli_query($con,$sql1);
if(mysqli_num_rows($res1)==0){
echo"<script>alert('INVALID USER');location='sorryerror.php';</script>";
}
else{
$row1=mysqli_fetch_array($res1);
$_SESSION=$row1['NAME'];
$_SESSION=$row1['ID'];
header('location:Main.php');
}
?>
	