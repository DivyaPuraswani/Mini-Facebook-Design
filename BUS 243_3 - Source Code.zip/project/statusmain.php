<!DOCTYPE html>
<html>
	<head>
		<title>Mini Facebook</title>
		<link rel="stylesheet" href="status2.css">
	</head>
	<body>
		<div id="first">
		<p id="text2"><b>Welcome to Mini Facebook...Connect Socially!!</b></p>
		</div>
		<a href="status.html"><div id="second">
		<p id="text1"><b>Upload Status</b></p>
		</div></a>
		<a href="pics.html"><div id="third">
		<p id="text1"><b>Upload Your Picture</b></p>
		</div></a>
		
	</body>
</html>