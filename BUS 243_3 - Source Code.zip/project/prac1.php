<?php
include'conn2.php';
 
	$sql = "select * from register";
	
	
	
	$res = mysqli_query($con, $sql);
	echo "<head>

<body >
<table  border=1 style='margin:auto;'>";
			while($row = mysqli_fetch_array($res))
				{
					echo "
						
						<tr><th>uname </th><td>".$row['NAME']."</td></tr>
						<tr><th>pass </th><td>".$row['PASSWORD']."</td></tr>
						
					
					";
				}

	echo "</table>
	</body>
	</head>";

?>