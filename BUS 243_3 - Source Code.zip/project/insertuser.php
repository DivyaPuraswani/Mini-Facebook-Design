<?php
 include'conn2.php';
 
 
	
	$USER_NAME=$_POST['fname'];
	$USER_EMAIL=$_POST['mailbox'];
	$USER_ADDRESS=$_POST['address'];
	$USER_CITY=$_POST['city'];
	$USER_DOB=$_POST['dob'];
	$JOIN_DATE=$_POST['joind'];
	$PASSWORD=$_POST['pass'];
	                	                   
	

 
	$sql="insert into USER_TABLE (USER_NAME, USER_DOB,USER_EMAIL,USER_ADDRESS,USER_CITY,JOIN_DATE,PASSWORD) values ('$USER_NAME','$USER_DOB','$USER_EMAIL','$USER_ADDRESS','$USER_CITY','$JOIN_DATE','$PASSWORD')";
 
	
    mysqli_query($con,$sql); 
	
	
 ?>
	<script>
	alert("Your Signup is successfull");
	location='Main.php';
	</script>		
