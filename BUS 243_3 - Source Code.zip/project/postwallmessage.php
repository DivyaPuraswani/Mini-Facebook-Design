<html>
<title>MINI_FACEBOOK</title>
<head><link type="text/css" rel="stylesheet" href="style.css"/>
</head>
	<body>
		 
		<div class="header">
		<form>
          <button type="submit" formaction="logout.php" class="submit1">Logout</button>
		<div id="img1" class="header"><img src="" height="" width=""/></div>
		</div>
		</form>
		</div>
		
		<div class="bodyx">

		<div id="intro1" class="bodyx">MINI FACEBOOK helps you to<br>connect SOCIALLY !!
		</div>
		<div id="intro2" class="bodyx">Welcome to MINI FACEBOOK!! <br><br><br>
		</div>
		<div id="img2" class="bodyx"><img src="enet.jpg" height="250" width="500"/>
		</div>
		<div id="intro3" class="bodyx"></div>
		<div id="form3" class="bodyx">
		<form action="" method="post">
		<br><br>Wall Message: <input type="text" id="namebox" placeholder="Message" name="message" /><br><br>
		    
		</div>
		  <button type="submit" formaction="insertwallmessage.php" class="button2">Upload</button>
		  </form>
		</div>
	</body>
</html>