<?php
$host="localhost";
$uname="root";
$upass="";
$database="mini_facebook";
$con=mysqli_connect($host,$uname,$upass,$database);
if(!$con){
die("connection error:");
}
?>
