<?php
 include'conn2.php';
 
 
	
	$WALL_MSG=$_POST['message'];

	                   
$sql="insert into WALL_MSG_TABLE(WALL_MSG) values ('$WALL_MSG')";
 $query = mysqli_query($con, $sql) or die (mysqli_error($con)); 
 
	
	
 ?>
	<script>
	alert("Your Message is uploaded successfully");
	location='postwallmessage.php';
	</script>			
