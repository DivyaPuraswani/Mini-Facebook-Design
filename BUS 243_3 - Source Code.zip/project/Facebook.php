<html>
<title>MINI_FACEBOOK</title>
<head><link type="text/css" rel="stylesheet" href="style.css"/>
</head>
	<body>
		 
		<div class="header">
		<form action="logincheck.php" method="post">

		<div id="img1" class="header"><img src="" height="" width=""/></div>
		<div id="form1" class="header">Email<br>
		<input type="mail" placeholder="Email" name="email">
		</div>
		<div id="form2" class="header">Password<br>
		<input type="password" placeholder="Password" name="pass">
		<input type="submit" class="submit1" value="Login" action="logincheck.php"/>
		 <a href="recover.html"><p>Forgotten Account?</p></a> 
		</div>
		</form>
		</div>
		
		<div class="bodyx">
		<form action="insertuser.php" method="post">

		<div id="intro1" class="bodyx">MINI FACEBOOK helps you to<br>connect SOCIALLY !!
		</div>
		<div id="intro2" class="bodyx">Create An Account
		</div>
		<div id="img2" class="bodyx"><img src="enet.jpg" height="250" width="500"/>
		</div>
		<div id="intro3" class="bodyx">Its free and always will be.</div>
		<div id="form3" class="bodyx">

		<input type="text" id="namebox" name="fname" placeholder="Name" /><br><br>
		<input type="Email" id="mailbox" placeholder="Email Address" name="mailbox" /><br><br>
	    <input type="Password" id="namebox" placeholder="Password" name="pass" width="35" height="35""/><br><br>
		Date of Birth: <input type="date" id="namebox" placeholder="Date" name="dob" /><br><br>
		<input type="text" name="address" placeholder="Address" id="namebox" /><br><br>
		<input type="text" name="city" placeholder="City" id="namebox"/><br><br>
		
		<br><br>
		
		</div>
		<input type="submit" class="button2" value="Create An Account" action="insertuser.php"/>
		</form>
		</div>
	</body>
</html>