<html>

<body>

<h1>A small example page to insert some data in to the MySQL database using PHP</h1>

<form action="reg1.php" method="post">

Name: <input type="text" name="fname" /><br><br>

Email:		<input type="text" name="mailbox" placeholder="Email Address or Mobile Number"><br>
Password: <input type="password" name="pass" /><br><br>
Address:	<input type="text" name="address" placeholder="Address"><br>
City:	<input type="text" name="city" placeholder="Address"><br>
Date of Birth:	<input type="date" name="dob" placeholder="Date"><br><br>
joining date:	<input type="date" name="joind" placeholder="Date"><br><br>
		
		<input type="submit" />

</form>

</body>
</html>