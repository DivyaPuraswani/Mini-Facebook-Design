<
<html>
<title>MINI_FACEBOOK</title>
<head><link type="text/css" rel="stylesheet" href="style.css"/>
<link rel="stylesheet" href="status2.css">
</head>
	<body>
		 
		<div class="header">
		<form>
        <br><center> <h2>WELCOME TO MINI FACEBOOK</center>
        <button type="submit" formaction="logout.php" class="submit1" align='right'>Logout</button>
		<div id="img1" class="header"><img src="" height="" width=""/></div>
		</div>
		</form>
		</div>	
		<div class="bodyx">

		<div id="second">
		<a><p id="text1"><b>Upload Status Message</b></p></a>
		<form action="" method="post">
		<br><br><center><input type="text" id="namebox" placeholder="Message" name="message" /></center><br><br>
		  <center><button type="submit" formaction="insertstatus.php">Upload</button></center>
		  </form>
		</div>
		<div id="third">
		<a><p id="text1"><b>Upload Photo</b></p></a>
			<form action="" method="post">
		<br><br><center><input type="text" id="namebox" placeholder="Photo" name="message" /></center><br><br>
		  <center><button type="submit" formaction="insertstatus.php">Upload</button></center>
		  </form>
		</div>
	</body>
</html>