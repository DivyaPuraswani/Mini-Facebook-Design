<html>
<title>MINI_FACEBOOK</title>
<head><link type="text/css" rel="stylesheet" href="style.css"/>
<link rel="stylesheet" href="status2.css">
</head>
	<body>
		 
		<div class="header">
		<form>
        <br><center> <h2>WELCOME TO MINI FACEBOOK</center>
        <button type="submit" formaction="logout.php" class="submit1" align='right'>Logout</button>
		<div id="img1" class="header"><img src="" height="" width=""/></div>
		</div>
		</form>
		</div>	
		<div class="bodyx">

		<div id="intro1" class="bodyx">
		</div>
		<div id="intro2" class="bodyx">
		</div>
		<div id="img2" class="bodyx"><img src="" height="250" width="500"/>
		</div>
		<a href="postphoto.php"><div id="second">
		<p id="text1"><b>Upload Status</b></p>
		</div></a>

		<a href="postwallmessage.php"><div id="third">
		<p id="text1"><b>Upload Wall Message</b></p>
		</div></a>
	</body>
</html>