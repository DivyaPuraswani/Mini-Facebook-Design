<?php
 include'conn2.php';
 
 
	
	$STATUS_MSG=$_POST['message'];
 
      $sql="insert into STATUS_TABLE (STATUS_MSG) values ('$STATUS_MSG')";
 $query = mysqli_query($con, $sql) or die (mysqli_error($myConnection)); 

	
    //mysqli_query($con,$sql); 
	
	
 ?>
	<script>
	alert("Your Status is uploaded successfully");
	location='postphoto.php';
	</script>		
