<html>
<title>MINI_FACEBOOK</title>
<head><link type="text/css" rel="stylesheet" href="style.css"/>
<link rel="stylesheet" href="status2.css">
</head>
	<body>
		 
		<div class="header">
		<form>
        <br><center> <h2>WELCOME TO MINI FACEBOOK</center>
        <button type="submit" formaction="logout.php" class="submit1" align='right'>Logout</button>
		<div id="img1" class="header"><img src="" height="" width=""/></div>
		</div>
		</form>
		</div>
		
		<div class="bodyx">

		<div id="intro1" class="bodyx">
		</div>
		<div id="intro2" class="bodyx">
		</div>
		<div id="img2" class="bodyx"><img src="" height="250" width="500"/>
		</div>
		<a href="postmain.php"><div id="second">
		<p id="text1"><b>Upload Post</b></p>
		</div></a>
	<div id="third">
		<a><p id="text1"><b>Search Friend</b></p></a>
			<form action="" method="POST">
		<br><br><center><input type="search" id="namebox" placeholder="Friend Name" name="friend" /></center><br><br>
		  <center><button type="submit" formaction="Main.php" value="FindData" name="search">Search</button></center>
		  		  	<?php

$con=mysql_connect('localhost', 'root', '');
$db=mysql_select_db('mini_facebook');


if(isset($_POST['search'])){    //trigger button click

  $search=$_POST['friend'];

  $query=mysql_query("select * from USER_TABLE where USER_NAME like '%{$search}%' ");

if (mysql_num_rows($query) > 0) {
  while ($row = mysql_fetch_array($query)) {
   echo '<p style="color: red; text-align: center">
      FOUND YOUR FRIEND !!
      </p>';
  }
}else{
    echo '<p style="color: red; text-align: center">
     SORRY CANNOT FIND YOUR FRIEND !!
      </p>';
  }

}

mysql_close();
?>	
		  
		  
		  </form>
		</div>
		
	</body>
</html>
		
		