<html>
<title>MINI_FACEBOOK</title>
<head><link type="text/css" rel="stylesheet" href="style.css"/>
</head>
	<body>
		 
		<div class="header">
		<form action="author.php" method="post">

		<div id="img1" class="header"><img src="" height="" width=""/></div>
		</div>
		</form>
		</div>
		
		<div class="bodyx">

		<div id="intro1" class="bodyx">MINI FACEBOOK helps you to<br>connect SOCIALLY !!
		</div>
		<div id="intro2" class="bodyx">Sorry Please Try again
		 <center><button type="submit" formaction="sorryerror.php" value="FindData" name="search">Try Again</button></center>
		</div>
		<div id="img2" class="bodyx"><img src="enet.jpg" height="250" width="500"/>
				 
		</div>
	</body>
</html>
<script>
	
	location='Facebook.php';
	</script>		